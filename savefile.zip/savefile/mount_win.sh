sudo mount -t fuse.vmhgfs-fuse .host:/ /mnt/ -o allow_other
