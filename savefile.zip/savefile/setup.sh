apt update &&
apt dist-upgrade -Vy &&
apt autoremove -y &&
apt autoclean &&
apt clean

adduser z3r0
usermod -a -G z3r0
chsh -s /bin/bash z3r0
echo "z3r0 ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers

wget -qO - https://download.sublimetext.com/sublimehq-pub.gpg | sudo apt-key add -
apt install apt-transport-https
echo "deb https://download.sublimetext.com/ apt/stable/" | sudo tee /etc/apt/sources.list.d/sublime-text.list

apt install sublime-text -y
apt install git -y
apt install ffuf -y
apt install gobuster -y
apt install tilix -y

cp nmap-auto.sh /opt/nmap-auto.sh

pushd /opt
ln -s $(pwd)/nmap-auto.sh /usr/local/bin/nmap-auto

git clone https://github.com/21y4d/nmapAutomator.git
ln -s $(pwd)/nmapAutomator/nmapAutomator.sh /usr/local/bin/nmapAutomator

gem install evil-winrm
popd

apt-get install maltego metasploit-framework burpsuite wireshark aircrack-ng hydra nmap beef-xss nikto -y
apt install okular -y

hostnamectl set-hostname checkmate
sed -i 's/kali/checkmate/g' /etc/hosts

reboot
