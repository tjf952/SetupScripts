#!/bin/bash
echo "newuser:newpass" > /tmp/creds.txt
useradd newuser -ou 0 -g root -s /bin/bash
chpasswd < /tmp/creds.txt
sudo JAVA_HOME=/usr/lib/jvm/default-java /opt/james-2.3.2/bin/run.sh